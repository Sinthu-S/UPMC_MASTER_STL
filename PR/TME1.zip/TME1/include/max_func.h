#ifndef H_GL_CALMAX
#define H_GL_CALMAX

int max_func(int tabNombe[], int tailleTab);

#endif
