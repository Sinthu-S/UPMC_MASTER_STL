#include <stdio.h>
#include <stdlib.h>

int max_func(int tabNombre[], int tailleTab){
  int tmpMax=tabNombre[0];
  int i;
  for(i=1;i<tailleTab;i++){
    if(tabNombre[i]>tmpMax)
      tmpMax=tabNombre[i];
  }
  return tmpMax;
}

