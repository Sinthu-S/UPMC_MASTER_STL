#include <stdio.h>
#include <stdlib.h>

int nfork(int nb_fils){
  int nb=0;
  while(nb_fils>0){
    if(fork()==0){
      printf("je suis un fils")
      return 0;
    }else{
      nb++;
    }
  }
  return (nb==0) ? -1 : nb;
}
